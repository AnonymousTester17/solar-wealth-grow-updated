import { useState, useEffect, useCallback } from "react";
import { Check, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { useToast } from "@/components/ui/use-toast";
import { getAuth, isSignInWithEmailLink, signInWithEmailLink } from "firebase/auth";
import { useAuth } from '@/contexts/AuthContext';
import { 
  createUserWithEmailAndPassword, 
  sendEmailVerification,
  sendPasswordResetEmail,
  onAuthStateChanged,
  reload,
} from "firebase/auth";

interface EmailVerificationProps {
  email: string;
  password: string;
  onVerificationSuccess: () => void;
  onClose: () => void;
  isOpen: boolean;
}

const EmailVerification = ({
  email,
  password,
  onVerificationSuccess,
  onClose,
  isOpen,
}: EmailVerificationProps) => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const { sendVerificationEmail } = useAuth();
  const [verificationSent, setVerificationSent] = useState(false);
  const auth = getAuth();

  const handleSendVerification = async () => {
    setLoading(true);
    try {
      await sendVerificationEmail(email);
      setVerificationSent(true);
      toast({
        description: "Verification email sent! Please check your inbox.",
        className: "bg-green-500 text-white",
      });
    } catch (error) {
      toast({
        description: error instanceof Error ? error.message : "Failed to send verification email",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const checkEmailVerification = useCallback(async () => {
    if (isSignInWithEmailLink(auth, window.location.href)) {
      try {
        await signInWithEmailLink(auth, email, window.location.href);
        onVerificationSuccess();
        onClose();
      } catch (error) {
        console.error('Error completing email verification:', error);
        toast({
          description: "Failed to complete email verification. Please try again.",
          variant: "destructive",
        });
      }
    }
  }, [auth, email, onVerificationSuccess, onClose, toast]);

  useEffect(() => {
    if (verificationSent) {
      const interval = setInterval(checkEmailVerification, 1000); // Check every second
      return () => clearInterval(interval);
    }
  }, [verificationSent, checkEmailVerification]);

  useEffect(() => {
    if (isOpen) {
      handleSendVerification();
    }
  }, [isOpen]);

  const handleForgotPassword = async () => {
    try {
      await sendPasswordResetEmail(auth, email);
      toast({
        description: "Password reset email sent! Please check your inbox.",
        className: "bg-green-500 text-white",
      });
    } catch (error: any) {
      console.error('Error sending password reset email:', error);
      toast({
        description: "Failed to send password reset email. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Verify Your Email</DialogTitle>
        </DialogHeader>
        <div className="flex flex-col items-center space-y-4">
          <p className="text-sm text-gray-500 text-center">
            We've sent a verification email to
            <br />
            <span className="font-medium">{email}</span>
          </p>
          <div className="flex flex-col items-center space-y-4">
            {verificationSent ? (
              <div className="flex items-center text-green-500 font-medium">
                <Check className="w-5 h-5 mr-1" />
                Verification Email Sent
              </div>
            ) : (
              <>
                <p className="text-sm text-gray-500 text-center">
                  Please click the verification link in the email to continue.
                  <br />
                  Don't see the email? Check your spam folder.
                </p>
                <div className="flex flex-col w-full gap-2">
                  <Button
                    onClick={handleSendVerification}
                    disabled={loading || verificationSent}
                    variant="outline"
                    className="w-full"
                  >
                    {loading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Sending...
                      </>
                    ) : verificationSent ? (
                      "Verification Email Sent"
                    ) : (
                      "Resend Verification Email"
                    )}
                  </Button>
                  <Button
                    onClick={handleForgotPassword}
                    variant="ghost"
                    className="text-sm text-blue-500 hover:text-blue-600"
                  >
                    Forgot Password?
                  </Button>
                </div>
              </>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default EmailVerification; 