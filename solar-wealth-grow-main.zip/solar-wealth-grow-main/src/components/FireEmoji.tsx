import { cn } from "@/lib/utils";

interface FireEmojiProps {
  className?: string;
}

const FireEmoji = ({ className }: FireEmojiProps) => {
  return (
    <span
      className={cn(
        "inline-block animate-flame transition-transform",
        className
      )}
      style={{
        animation: "flame 0.8s infinite"
      }}
    >
      🔥
    </span>
  );
};

export default FireEmoji; 