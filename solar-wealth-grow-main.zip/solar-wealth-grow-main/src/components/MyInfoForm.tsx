import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { database } from "@/lib/firebase";
import { ref, update } from "firebase/database";
import { useToast } from "@/components/ui/use-toast";

interface MyInfoFormProps {
  isOpen: boolean;
  onClose: () => void;
  userData: {
    id: string;
    fullName: string;
    phone: string;
  } | null;
}

const MyInfoForm = ({ isOpen, onClose, userData }: MyInfoFormProps) => {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    fullName: userData?.fullName || "",
    phone: userData?.phone || "",
  });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userData?.id) return;

    setLoading(true);
    try {
      const userRef = ref(database, `User Signup details/${userData.id}`);
      await update(userRef, {
        fullName: formData.fullName,
        phone: formData.phone,
      });

      toast({
        description: "Profile updated successfully!",
        className: "bg-green-500 text-white",
      });
      onClose();
    } catch (error) {
      toast({
        description: "Failed to update profile",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Update Profile</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 mt-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Full Name</label>
            <Input
              value={formData.fullName}
              onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
              placeholder="Enter your full name"
              required
            />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium">Phone Number</label>
            <Input
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              placeholder="Enter your phone number"
              type="tel"
              required
            />
          </div>
          <div className="flex justify-end space-x-2">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              disabled={loading}
            >
              Cancel
            </Button>
            <Button type="submit" disabled={loading}>
              {loading ? "Updating..." : "Update Profile"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default MyInfoForm; 