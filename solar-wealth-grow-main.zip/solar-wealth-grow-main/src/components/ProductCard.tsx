import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import FireEmoji from "./FireEmoji";

interface ProductCardProps {
  id: string;
  name: string;
  price: number;
  image: string;
  revenue: string;
  dailyEarnings: number;
  totalRevenue: number;
  investQuantity: number;
  limit: string;
  validDays: number;
  isHot?: boolean;
}

const ProductCard = ({
  name,
  price,
  image,
  revenue,
  dailyEarnings,
  totalRevenue,
  investQuantity,
  limit,
  validDays,
  isHot = false,
}: ProductCardProps) => {
  return (
    <Card className="bg-white rounded-xl shadow-lg overflow-hidden animate-fade-in hover:shadow-xl transition-shadow">
      <CardContent className="p-0">
        <div className="flex min-h-[160px]">
          {/* Left side - Title and Image */}
          <div className="relative w-32 flex flex-col">
            <div className="p-2 bg-facebook-50 flex-shrink-0">
              <h3 className="font-bold text-xs text-gray-800 text-center leading-tight">{name}</h3>
            </div>
            <div className="flex-1 relative">
              <img
                src={image}
                alt={name}
                className="w-full h-full object-cover"
              />
              {isHot && (
                <div className="absolute bottom-1 left-1 flex space-x-1">
                  <FireEmoji />
                  <FireEmoji />
                  <FireEmoji />
                </div>
              )}
            </div>
          </div>
          
          {/* Right side - Content and Button */}
          <div className="flex-1 p-3 flex flex-col justify-between">
            <div>
              <div className="flex justify-end items-start mb-2">
                {isHot && (
                  <Badge className="bg-orange-500 text-white text-xs px-2 py-1">
                    Win ₹{totalRevenue.toLocaleString()}
                  </Badge>
                )}
              </div>
              
              <div className="space-y-1 text-xs">
                <div className="flex justify-between">
                  <span className="text-gray-500">Limit:</span>
                  <span className="font-semibold">{limit}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Valid days:</span>
                  <span className="font-semibold">{validDays}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Daily income:</span>
                  <span className="font-semibold text-facebook-600">₹{dailyEarnings}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Total income:</span>
                  <span className="font-semibold text-green-600">₹{totalRevenue.toLocaleString()}</span>
                </div>
              </div>
            </div>
            
            <Button className="w-full bg-facebook-500 hover:bg-facebook-600 text-white text-xs py-2 mt-2 flex-shrink-0">
              Invest ₹{price.toLocaleString()}
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default ProductCard;
