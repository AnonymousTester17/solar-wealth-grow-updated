import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  getAuth, 
  signInWithEmailAndPassword, 
  signOut, 
  onAuthStateChanged,
  User as FirebaseUser,
  createUserWithEmailAndPassword,
  updateProfile,
  sendSignInLinkToEmail
} from 'firebase/auth';
import { doc, setDoc, serverTimestamp, getFirestore, getDoc } from 'firebase/firestore';
import { FirebaseError } from 'firebase/app';
import { auth, db } from '@/lib/firebase';

interface User {
  id: string;
  email: string;
  fullName: string;
  totalInvestmentReturns: number;
  todayReturns: number;
}

interface AuthContextType {
  user: User | null;
  loading: boolean;
  signUp: (email: string, password: string, fullName: string) => Promise<FirebaseUser>;
  login: (email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  sendVerificationEmail: (email: string) => Promise<void>;
}

export const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }: { children: React.ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const auth = getAuth();
  const db = getFirestore();

  // Update localStorage whenever user changes
  useEffect(() => {
    if (user) {
      localStorage.setItem('user', JSON.stringify(user));
    } else {
      localStorage.removeItem('user');
    }
  }, [user]);

  const signUp = async (email: string, password: string, fullName: string) => {
    try {
      const sanitizedEmail = email.toLowerCase().trim();
      const userCredential = await createUserWithEmailAndPassword(auth, sanitizedEmail, password);
      const user = userCredential.user;

      // Create user document immediately
      await setDoc(doc(db, "users", user.uid), {
        fullName,
        email: sanitizedEmail,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });

      // Set display name
      await updateProfile(user, {
        displayName: fullName,
      });

      return user;
    } catch (error) {
      if (error instanceof FirebaseError) {
        if (error.code === 'auth/email-already-in-use') {
          throw new Error('An account with this email already exists');
        }
      }
      throw error;
    }
  };

  const sendVerificationEmail = async (email: string) => {
    try {
      const sanitizedEmail = email.toLowerCase().trim();
      const actionCodeSettings = {
        url: window.location.origin,
        handleCodeInApp: true,
      };
      await sendSignInLinkToEmail(auth, sanitizedEmail, actionCodeSettings);
      localStorage.setItem('emailForSignIn', sanitizedEmail);
    } catch (error) {
      if (error instanceof FirebaseError) {
        if (error.code === 'auth/invalid-email') {
          throw new Error('Invalid email address');
        }
      }
      throw error;
    }
  };

  const login = async (email: string, password: string) => {
    try {
      const userCredential = await signInWithEmailAndPassword(auth, email, password);
      
      if (!userCredential.user.emailVerified) {
        throw new Error('Please verify your email before logging in');
      }

      const userDoc = await getDoc(doc(db, "users", userCredential.user.uid));
      
      if (!userDoc.exists()) {
        throw new Error('User not found');
      }

      const userData = userDoc.data();
      setUser({
        id: userCredential.user.uid,
        email: userData.email,
        fullName: userData.fullName,
        totalInvestmentReturns: userData.totalInvestmentReturns || 0,
        todayReturns: userData.todayReturns || 0
      });
    } catch (error) {
      console.error('Error logging in:', error);
      if (error instanceof FirebaseError && error.code === 'auth/invalid-credential') {
        throw new Error('Invalid email or password');
      }
      throw error;
    }
  };

  const logout = async () => {
    try {
      await signOut(auth);
      setUser(null);
      localStorage.removeItem('user');
    } catch (error) {
      console.error('Error logging out:', error);
      throw error;
    }
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser && firebaseUser.emailVerified) {
        try {
          const userDoc = await getDoc(doc(db, "users", firebaseUser.uid));
          
          if (userDoc.exists()) {
            const userData = userDoc.data();
            setUser({
              id: firebaseUser.uid,
              email: userData.email,
              fullName: userData.fullName,
              totalInvestmentReturns: userData.totalInvestmentReturns || 0,
              todayReturns: userData.todayReturns || 0
            });
          }
        } catch (error) {
          console.error('Error fetching user data:', error);
        }
      } else {
        setUser(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, [auth, db]);

  const value = {
    user,
    loading,
    signUp,
    login,
    logout,
    sendVerificationEmail
  };

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  );
};

export default AuthContext; 