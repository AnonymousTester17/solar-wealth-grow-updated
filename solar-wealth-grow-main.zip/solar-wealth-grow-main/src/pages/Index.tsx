import { useEffect, useState } from "react";
import Navigation from "../components/Navigation";
import ProductCard from "@/components/ProductCard";
import { MessageSquare, User, Wallet } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";

const Index = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [animatedValue, setAnimatedValue] = useState(0);
  const targetValue = user?.totalInvestmentReturns || 0;

  useEffect(() => {
    const duration = 2000; // 2 seconds
    const steps = 60;
    const increment = targetValue / steps;
    let currentStep = 0;

    const timer = setInterval(() => {
      currentStep++;
      setAnimatedValue(Math.round(increment * currentStep));
      
      if (currentStep >= steps) {
        setAnimatedValue(targetValue);
        clearInterval(timer);
      }
    }, duration / steps);

    return () => clearInterval(timer);
  }, [targetValue]);

  const products = [
    {
      id: "1",
      name: "O-R1",
      price: 500,
      image: "https://images.unsplash.com/photo-1501854140801-50d01698950b?w=400&h=200&fit=crop",
      revenue: "5 Days",
      dailyEarnings: 100,
      totalRevenue: 1000,
      investQuantity: 0,
      limit: "0/1",
      validDays: 5,
      isHot: true,
    },
    {
      id: "2",
      name: "O-R2",
      price: 2000,
      image: "https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?w=400&h=200&fit=crop",
      revenue: "10 Days",
      dailyEarnings: 200,
      totalRevenue: 4000,
      investQuantity: 0,
      limit: "0/1",
      validDays: 10,
      isHot: false,
    },
    {
      id: "3",
      name: "O-R3",
      price: 5000,
      image: "https://images.unsplash.com/photo-1482938289607-e9573fc25ebb?w=400&h=200&fit=crop",
      revenue: "15 Days",
      dailyEarnings: 500,
      totalRevenue: 12500,
      investQuantity: 0,
      limit: "0/1",
      validDays: 15,
      isHot: true,
    },
    {
      id: "4",
      name: "O-R4",
      price: 10000,
      image: "https://images.unsplash.com/photo-1509316975850-ff9c5deb0cd9?w=400&h=200&fit=crop",
      revenue: "30 Days",
      dailyEarnings: 1000,
      totalRevenue: 30000,
      investQuantity: 0,
      limit: "0/1",
      validDays: 30,
      isHot: false,
    },
    {
      id: "5",
      name: "O-R5",
      price: 25000,
      image: "https://images.unsplash.com/photo-1466611653911-95081537e5b7?w=400&h=200&fit=crop",
      revenue: "60 Days",
      dailyEarnings: 2500,
      totalRevenue: 75000,
      investQuantity: 0,
      limit: "0/1",
      validDays: 60,
      isHot: true,
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-facebook-50 pb-20">
      {/* Header */}
      <div className="bg-gradient-to-r from-facebook-800 to-facebook-600 text-white p-4">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <img src="/logo.png" alt="Solar Growth Logo" className="h-10 w-auto" />
          </div>
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-facebook-700 rounded-full flex items-center justify-center cursor-pointer">
              <MessageSquare className="w-5 h-5" />
            </div>
            <div 
              className="w-8 h-8 bg-facebook-700 rounded-full flex items-center justify-center cursor-pointer"
              onClick={() => navigate('/profile')}
            >
              <User className="w-5 h-5" />
            </div>
          </div>
        </div>
        
        <div className="bg-gradient-to-r from-facebook-600 to-facebook-500 rounded-2xl p-4 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-transparent to-black opacity-20"></div>
          <div className="relative z-10 flex items-center justify-between">
            <div>
              <h2 className="text-lg font-bold mb-2 text-facebook-300">Total Investment Returns</h2>
              <div className="text-2xl font-bold">₹ {animatedValue}</div>
              <div className="mt-3 flex items-center space-x-4">
                <div className="bg-facebook-300 text-facebook-900 px-3 py-1 rounded-full text-sm font-semibold">
                  Today Returns: <span className="text-green-600">₹{user?.todayReturns || 0}</span>
                </div>
              </div>
            </div>
            <div className="w-14 h-14">
              <div className="w-full h-full bg-facebook-400 rounded-full opacity-30 flex items-center justify-center">
                <Wallet className="w-7 h-7 text-white" />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Products Grid */}
      <div className="p-4">
        <div className="space-y-4">
          {products.map((product) => (
            <ProductCard key={product.id} {...product} />
          ))}
        </div>
      </div>

      <Navigation />
    </div>
  );
};

export default Index;
