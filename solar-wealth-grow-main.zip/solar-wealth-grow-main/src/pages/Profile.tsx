import { useState } from "react";
import Navigation from "../components/Navigation";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { User, Settings, FileText, Wallet, ArrowUp, ArrowDown } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import MyInfoForm from "@/components/MyInfoForm";
import PasswordChangeForm from "@/components/PasswordChangeForm";

const Profile = () => {
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  const [isLanguageDialogOpen, setIsLanguageDialogOpen] = useState(false);
  const [selectedLanguage, setSelectedLanguage] = useState("English");
  const [isMyInfoOpen, setIsMyInfoOpen] = useState(false);
  const [isPasswordChangeOpen, setIsPasswordChangeOpen] = useState(false);

  const walletStats = [
    { label: "Available Balance", value: `₹ ${user?.totalInvestmentReturns || 0}` },
    { label: "Deposit Balance", value: "₹ 0" },
    { label: "Withdrawable", value: "₹ 0" },
  ];

  const quickActions = [
    { name: "Deposit", icon: ArrowUp, color: "bg-facebook-100", textColor: "text-facebook-600" },
    { name: "Withdraw", icon: ArrowDown, color: "bg-blue-100", textColor: "text-blue-600" },
    { name: "BankCard", icon: Wallet, color: "bg-purple-100", textColor: "text-purple-600" },
    { name: "My Order", icon: FileText, color: "bg-gray-100", textColor: "text-gray-600" },
  ];

  const languages = [
    "English",
    "Hindi",
    "Tamil",
    "Telugu",
    "Malayalam",
    "Kannada",
    "Bengali",
    "Marathi"
  ];

  const handleLanguageChange = (language: string) => {
    setSelectedLanguage(language);
    // Here you would implement the actual language change logic
    setIsLanguageDialogOpen(false);
  };

  const handleLogout = async () => {
    try {
      await logout();
      navigate('/');
    } catch (error) {
      console.error('Error logging out:', error);
    }
  };

  const menuItems = [
    { name: "VIP level", icon: "💎", color: "text-yellow-600" },
    { name: "Fund record", icon: "📋", color: "text-facebook-600" },
    { name: "Commission", icon: "👥", color: "text-green-600" },
    { name: "Help Center", icon: "💬", color: "text-blue-600", onClick: () => window.location.href = "https://wa.me/919542656312" },
    { name: "My Order", icon: "📦", color: "text-gray-600" },
    { name: "LoginPWD", icon: "🔒", color: "text-red-600", onClick: () => setIsPasswordChangeOpen(true) },
    { name: "Language", icon: "🌐", color: "text-indigo-600", onClick: () => setIsLanguageDialogOpen(true) },
    { name: "Download APP", icon: "⬇️", color: "text-green-600" },
    { name: "MyInfo", icon: "👤", color: "text-gray-600", onClick: () => setIsMyInfoOpen(true) },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-facebook-50 pb-20">
      {/* Account Section */}
      <div className="bg-gradient-to-r from-facebook-800 to-facebook-600 text-white p-4">
        <div className="bg-gradient-to-r from-facebook-600 to-facebook-500 rounded-2xl p-4 relative overflow-hidden mb-4">
          <div className="absolute inset-0 bg-gradient-to-r from-transparent to-black opacity-20"></div>
          <div className="relative z-10 flex items-center space-x-4">
            <div className="w-16 h-16 bg-facebook-400 rounded-full flex items-center justify-center">
              <User className="w-8 h-8 text-white" />
            </div>
            <div>
              <div className="font-bold text-lg">{user?.fullName}</div>
              <div className="text-facebook-200">{user?.phone}</div>
            </div>
          </div>
        </div>

        {/* My Wallet Section */}
        <div className="bg-gradient-to-r from-facebook-600 to-facebook-500 rounded-2xl p-4">
          <h3 className="text-lg font-bold mb-4 text-facebook-300">My Wallet</h3>
          <div className="grid grid-cols-3 gap-4">
            {walletStats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-xl font-bold">{stat.value}</div>
                <div className="text-sm text-facebook-300">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="p-4">
        <Card className="bg-white rounded-xl shadow-lg mb-6">
          <CardContent className="p-4">
            <div className="grid grid-cols-4 gap-4">
              {quickActions.map((action, index) => {
                const Icon = action.icon;
                return (
                  <div key={index} className="text-center">
                    <div className={`w-12 h-12 mx-auto rounded-full flex items-center justify-center ${action.color} ${action.textColor} mb-2`}>
                      <Icon className="w-6 h-6" />
                    </div>
                    <span className={`text-sm ${action.textColor}`}>{action.name}</span>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Invite Button */}
        <Button 
          className="w-full bg-facebook-500 hover:bg-facebook-600 text-white py-6 text-lg mb-6"
          onClick={() => navigate('/teams')}
        >
          Invite friends to get rewards
        </Button>

        {/* Menu Items */}
        <Card className="bg-white rounded-xl shadow-lg mb-6">
          <CardContent className="p-4">
            <div className="grid grid-cols-3 gap-4">
              {menuItems.map((item, index) => (
                <div 
                  key={index} 
                  className="text-center p-4 cursor-pointer hover:bg-gray-50 rounded-lg"
                  onClick={item.onClick}
                >
                  <div className={`text-2xl mb-2 ${item.color}`}>{item.icon}</div>
                  <span className="text-sm text-gray-600">{item.name}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Logout Button */}
        <Button 
          variant="destructive"
          className="w-full py-6 text-lg"
          onClick={handleLogout}
        >
          Logout
        </Button>
      </div>

      {/* Language Selection Dialog */}
      <Dialog open={isLanguageDialogOpen} onOpenChange={setIsLanguageDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Select Language</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-4 p-4">
            {languages.map((language) => (
              <Button
                key={language}
                variant={selectedLanguage === language ? "default" : "outline"}
                className="w-full"
                onClick={() => handleLanguageChange(language)}
              >
                {language}
              </Button>
            ))}
          </div>
        </DialogContent>
      </Dialog>

      {/* MyInfo Form */}
      <MyInfoForm
        isOpen={isMyInfoOpen}
        onClose={() => setIsMyInfoOpen(false)}
        userData={user}
      />

      {/* Password Change Form */}
      <PasswordChangeForm
        isOpen={isPasswordChangeOpen}
        onClose={() => setIsPasswordChangeOpen(false)}
        userId={user?.id || ""}
      />

      <Navigation />
    </div>
  );
};

export default Profile;
