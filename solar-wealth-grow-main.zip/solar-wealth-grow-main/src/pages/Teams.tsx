import { useState } from "react";
import Navigation from "@/components/Navigation";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { User, Share2, X } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

const Teams = () => {
  const { toast } = useToast();
  const [showShareOptions, setShowShareOptions] = useState(false);

  const referralStats = [
    { label: "Total Commission", value: "₹ 0", color: "text-facebook-600" },
    { label: "Gross Income", value: "₹ 0", color: "text-facebook-600" },
    { label: "Invite User", value: "0", color: "text-gray-600" },
  ];

  const levels = [
    { level: "Level1", commission: "₹0", users: "0" },
    { level: "Level2", commission: "₹0", users: "0" },
    { level: "Level3", commission: "₹0", users: "0" },
  ];

  const shareOptions = [
    { name: "WhatsApp", icon: "💬", color: "bg-green-500", action: () => window.location.href = `whatsapp://send?text=${encodeURIComponent("https://www.solarwealth.com/register...")}` },
    { name: "Telegram", icon: "✈️", color: "bg-blue-500", action: () => window.location.href = `https://t.me/share/url?url=${encodeURIComponent("https://www.solarwealth.com/register...")}` },
    { name: "Facebook", icon: "👥", color: "bg-facebook-500", action: () => window.location.href = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent("https://www.solarwealth.com/register...")}` },
    { name: "Twitter", icon: "🐦", color: "bg-sky-500", action: () => window.location.href = `https://twitter.com/intent/tweet?url=${encodeURIComponent("https://www.solarwealth.com/register...")}` },
    { name: "Email", icon: "📧", color: "bg-red-500", action: () => window.location.href = `mailto:?body=${encodeURIComponent("https://www.solarwealth.com/register...")}` },
    { name: "SMS", icon: "💌", color: "bg-yellow-500", action: () => window.location.href = `sms:?body=${encodeURIComponent("https://www.solarwealth.com/register...")}` },
  ];

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText("https://www.solarwealth.com/register...");
      toast({
        description: "Copied successfully",
        className: "fixed bottom-16 right-4 bg-green-500 text-white border-none",
      });
    } catch (err) {
      toast({
        description: "Failed to copy",
        variant: "destructive",
        className: "fixed bottom-16 right-4",
      });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-facebook-50 pb-20">
      {/* Header */}
      <div className="bg-gradient-to-r from-facebook-800 to-facebook-600 text-white p-4">
        <div className="text-center">
          <div className="flex justify-center items-center mb-4">
            <div className="flex space-x-2">
              {[1, 2, 3].map((i) => (
                <div key={i} className="w-16 h-20 bg-facebook-700 rounded-lg flex items-center justify-center">
                  <User className="w-8 h-8 text-gray-300" />
                </div>
              ))}
            </div>
            <div className="ml-4 flex space-x-2">
              <div className="w-12 h-12 bg-yellow-500 rounded-full flex items-center justify-center">
                💰
              </div>
              <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center">
                💵
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="p-4">
        <Card className="bg-white rounded-xl shadow-lg mb-6">
          <CardContent className="p-4">
            <div className="grid grid-cols-3 gap-4 text-center">
              {referralStats.map((stat, index) => (
                <div key={index}>
                  <div className={`text-2xl font-bold ${stat.color}`}>
                    {stat.value}
                  </div>
                  <div className="text-sm text-gray-500 mt-1">
                    {stat.label}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Referral Link */}
        <Card className="bg-white rounded-xl shadow-lg mb-6">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Input
                value="https://www.solarwealth.com/register..."
                readOnly
                className="flex-1 bg-gray-50 text-gray-400"
              />
              <Button 
                className="bg-facebook-500 hover:bg-facebook-600 text-white"
                onClick={handleCopy}
              >
                Copy
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Invite Button */}
        <Button 
          className="w-full bg-facebook-500 hover:bg-facebook-600 text-white py-3 text-lg mb-6"
          onClick={() => setShowShareOptions(true)}
        >
          Invite Friends
        </Button>

        {/* Share Options Modal */}
        {showShareOptions && (
          <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-end justify-center">
            <div className="bg-white w-full rounded-t-2xl p-4 animate-slide-up">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-semibold">Share via</h3>
                <button 
                  onClick={() => setShowShareOptions(false)}
                  className="p-2 hover:bg-gray-100 rounded-full"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
              <div className="grid grid-cols-4 gap-4 mb-4">
                {shareOptions.map((option, index) => (
                  <button
                    key={index}
                    className="flex flex-col items-center space-y-2"
                    onClick={() => {
                      option.action();
                      setShowShareOptions(false);
                    }}
                  >
                    <div className={`w-14 h-14 ${option.color} rounded-full flex items-center justify-center text-2xl`}>
                      {option.icon}
                    </div>
                    <span className="text-sm text-gray-600">{option.name}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Levels */}
        <Card className="bg-white rounded-xl shadow-lg mb-6">
          <CardContent className="p-4">
            <div className="grid grid-cols-3 gap-4 mb-4">
              {levels.map((level, index) => (
                <div key={index} className="text-center">
                  <div className="font-semibold text-gray-800">{level.level}</div>
                  {index === 0 && <div className="w-full h-1 bg-facebook-500 rounded mt-1"></div>}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Commission Cards */}
        <div className="grid grid-cols-2 gap-4">
          <Card className="bg-gradient-to-br from-yellow-400 to-yellow-500 rounded-xl shadow-lg">
            <CardContent className="p-4 text-center">
              <div className="w-8 h-8 bg-white rounded-full flex items-center justify-center mx-auto mb-2">
                🎁
              </div>
              <div className="text-white font-bold text-lg">₹0</div>
              <div className="text-yellow-100 text-sm">Commission</div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-facebook-600 to-facebook-700 rounded-xl shadow-lg">
            <CardContent className="p-4 text-center">
              <div className="w-8 h-8 bg-white rounded-full flex items-center justify-center mx-auto mb-2">
                👥
              </div>
              <div className="text-white font-bold text-lg">0</div>
              <div className="text-facebook-200 text-sm">Invite User</div>
            </CardContent>
          </Card>
        </div>
      </div>

      <Navigation />
    </div>
  );
};

export default Teams;
